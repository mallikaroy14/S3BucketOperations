package com.bajaj;

public interface Shape {

    public void area();

    public void displayInfo();

}
