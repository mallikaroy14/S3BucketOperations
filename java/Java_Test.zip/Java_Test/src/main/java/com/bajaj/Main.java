package com.bajaj;

public class Main {
    public static void main(String[] args) {
//        Car car = new Car();
//
//        car.make = "TATA";
//        car.model = "Model 1";
//        car.year = 2024;
//        car.display();

//        Circle circle = new Circle();
//        circle.area();
//        circle.displayInfo();
//
//        Rectangule rectangule = new Rectangule();
//        rectangule.area();
//        rectangule.displayInfo();

//        ExceptionHandling exceptionHandling = new ExceptionHandling();
//        exceptionHandling.userInput();

        ArrayCollection arrayCollection = new ArrayCollection();
        arrayCollection.sum();
        arrayCollection.average();

    }
}